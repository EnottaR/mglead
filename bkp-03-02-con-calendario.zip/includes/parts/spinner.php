<div id="logout-overlay">
    <div class="spinner"></div>
    <p>Chiusura sessione in corso...</p>
</div>