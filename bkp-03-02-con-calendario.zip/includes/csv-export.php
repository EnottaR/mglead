<?php
require '../includes/db.php';
session_start();

if (!isset($_SESSION['loggedin']) || !isset($_SESSION['user_id'])) {
    die("Accesso negato.");
}

$client_id = $_SESSION['user_id'];

setlocale(LC_TIME, 'it_IT.UTF-8');

$stmt_user = $conn->prepare("SELECT username FROM clients WHERE id = ?");
$stmt_user->bind_param("i", $client_id);
$stmt_user->execute();
$stmt_user->bind_result($username);
$stmt_user->fetch();
$stmt_user->close();

$timestamp = date("Y-m-d");
$sanitized_username = preg_replace('/[^a-zA-Z0-9_-]/', '', $username);
$filename = "lead-esportati-{$timestamp}-{$sanitized_username}.csv";

header('Content-Type: text/csv; charset=utf-8');
header("Content-Disposition: attachment; filename=\"$filename\"");
echo "\xEF\xBB\xBF"; // questo è un byte per permettere la formattazione utf-8, non rimuovere

$output = fopen('php://output', 'w');

fputcsv($output, ['Lead_ID', 'Nome', 'Cognome', 'Email', 'Telefono', 'Status', 'Creato il', 'Messaggio'], ';');

$stmt = $conn->prepare("
    SELECT l.id, p.name, p.surname, p.email, l.phone, l.message, 
           MAX(sl.label) as status_label, l.created_at, HEX(l.iv) as iv
    FROM leads l
    JOIN personas p ON l.personas_id = p.id
    LEFT JOIN status_labels sl ON l.status_id = sl.leads_status_id
    WHERE l.clients_id = ?
    GROUP BY l.id, p.name, p.surname, p.email, l.phone, l.message, l.created_at, l.iv
    ORDER BY l.created_at DESC
");
// c'è un errore nel db, ho aggiunto MAX(sl.label) per evitare le duplicazioni di lead
// prendendo solo l'ultimo valore di status_label, così evitiamo errori in fase di export

$stmt->bind_param("i", $client_id);
$stmt->execute();
$result = $stmt->get_result();

function decryptData($encryptedData, $iv, $encryption_key) {
    if (!$encryptedData || !$iv || !$encryption_key) return "Errore: dati mancanti!";
    if (ctype_xdigit($iv) && strlen($iv) === 32) $iv = hex2bin($iv);
    return openssl_decrypt($encryptedData, 'aes-256-cbc', $encryption_key, 0, $iv) ?: "Errore: decriptazione fallita!";
}

$stmt_key = $conn->prepare("SELECT encryption_key FROM clients WHERE id = ?");
$stmt_key->bind_param("i", $client_id);
$stmt_key->execute();
$stmt_key->bind_result($encryption_key);
$stmt_key->fetch();
$stmt_key->close();

while ($row = $result->fetch_assoc()) {
    $decryptedPhone = decryptData($row['phone'], $row['iv'], $encryption_key);
    $decryptedMessage = str_replace("\n", " ", decryptData($row['message'], $row['iv'], $encryption_key));

    fputcsv($output, [
        $row['id'],
        $row['name'],
        $row['surname'],
        $row['email'],
        $decryptedPhone,
        $row['status_label'] ?: 'Sconosciuto',
        strftime("%d %b %Y - %H:%M", strtotime($row['created_at'])),
        $decryptedMessage
    ], ';');
}

fclose($output);
$stmt->close();
$conn->close();
?>
