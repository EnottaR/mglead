<?php
require 'db.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    echo json_encode(["status" => "error", "message" => "⚠️ Nessun dato ricevuto"]);
    exit;
}

if (!isset($data['lead_id']) || !isset($data['status_id'])) {
    echo json_encode(["status" => "error", "message" => "⚠️ Dati mancanti!"]);
    exit;
}

$lead_id = intval($data['lead_id']);
$status_id = intval($data['status_id']);

if (!$conn) {
    echo json_encode(["status" => "error", "message" => "⚠️ Errore di connessione al database"]);
    exit;
}

// Controllo se il lead esiste
$stmt = $conn->prepare("SELECT id FROM leads WHERE id = ?");
if (!$stmt) {
    echo json_encode(["status" => "error", "message" => "⚠️ Errore nella preparazione della query"]);
    exit;
}
$stmt->bind_param("i", $lead_id);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    echo json_encode(["status" => "error", "message" => "⚠️ Lead non trovato"]);
    exit;
}
$stmt->close();

$stmt = $conn->prepare("UPDATE leads SET status_id = ?, status_updated_at = NOW() WHERE id = ?");
if (!$stmt) {
    echo json_encode(["status" => "error", "message" => "⚠️ Errore nella preparazione dell'aggiornamento"]);
    exit;
}

$stmt->bind_param("ii", $status_id, $lead_id);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "<i class='fas fa-check-circle'></i> Status aggiornato con successo!"]);
} else {
    echo json_encode(["status" => "error", "message" => "⚠️ Errore durante l'aggiornamento"]);
}

$stmt->close();
$conn->close();
?>
