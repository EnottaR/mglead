document.addEventListener("DOMContentLoaded", function () {
    const notificaBtn = document.getElementById("notifica-btn");
    const notificaBox = document.getElementById("notifica-box");
    const notificaContenuto = document.getElementById("notifica-contenuto");
    const chiudiNotifica = document.getElementById("chiudi-notifica");
    const notificationDot = document.getElementById("new-lead-notification");

    // Se gli elementi non esistono, esci (evita errori su pagine senza notifiche)
    if (!notificaBtn || !notificaBox || !notificationDot) return;

    function checkNewLeads() {
        fetch("includes/new-lead-alert.php")
            .then(response => response.json())
            .then(data => {
                if (data.status === "success" && data.new_leads > 0) {
                    notificationDot.style.display = "block"; // Mostra il pallino

                    let leadHtml = "";
                    data.leads.forEach(lead => {
                        leadHtml += `<div class="notifica-lead">
                            🟢 Nuovo lead da <span>${lead.name} ${lead.surname}</span><br>
                            <small>${lead.created_at}</small>
                        </div>`;
                    });

                    notificaContenuto.innerHTML = leadHtml;
                } else {
                    notificationDot.style.display = "none"; // Nasconde il pallino
                    notificaContenuto.innerHTML = "<p>Non hai nessuna novità.</p>";
                }
            })
            .catch(error => console.error("Errore nel controllo nuovi lead:", error));
    }

    // 🔹 Click sulla campana per mostrare le notifiche
    notificaBtn.addEventListener("click", function () {
        notificaBox.classList.toggle("show");
        checkNewLeads();
    });

    // 🔹 Chiudi la notifica quando si clicca fuori
    document.addEventListener("click", function (event) {
        if (!notificaBox.contains(event.target) && !notificaBtn.contains(event.target)) {
            notificaBox.classList.remove("show");
        }
    });

    chiudiNotifica.addEventListener("click", function () {
        notificaBox.classList.remove("show");
    });

    // Controlla nuovi lead ogni 10 secondi
    setInterval(checkNewLeads, 10000);
    checkNewLeads();
});
